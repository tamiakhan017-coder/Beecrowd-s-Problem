//https://judge.beecrowd.com/en/problems/view/1000
#include <stdio.h>
 
int main() {
 printf("Hello World!\n");
 return 0;
}