//https://judge.beecrowd.com/en/problems/view/1001
#include<stdio.h>

int main() {
    int A , B , X;
    scanf("%d %d" , &A, &B);
    X = A + B;
    printf("X = %d\n" , X);
    return 0;
}