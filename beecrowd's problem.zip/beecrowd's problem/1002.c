//https://judge.beecrowd.com/en/problems/view/1002
#include <stdio.h>
 
int main() {
 
    double r,A;
    const double pi = 3.14159;
    scanf("%lf",&r);
    A=pi*r*r;
    printf("A=%.4lf\n" , A);
 
    return 0;
}