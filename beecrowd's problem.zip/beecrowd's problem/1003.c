//https://judge.beecrowd.com/en/problems/view/1003
#include <stdio.h>
 
int main() {
 
    int A ,B , SOMA;
    scanf("%d",&A);
    scanf("%d",&B);
    SOMA = A + B;
    printf("SOMA = %d\n" , SOMA);
 
    return 0;
}