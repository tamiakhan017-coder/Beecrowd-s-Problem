//https://judge.beecrowd.com/en/problems/view/1004
#include <stdio.h>
 
int main() {
 
    int PROD, A, B;
    scanf("%d",&A);
    scanf("%d",&B);
    PROD = A * B;
    printf("PROD = %d\n", PROD);
    
    return 0;
}