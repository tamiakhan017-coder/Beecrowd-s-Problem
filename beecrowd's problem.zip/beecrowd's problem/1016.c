//https://judge.beecrowd.com/en/problems/view/1016
#include <stdio.h>
 
int main() {
 int D, minutos;
 scanf("%d",&D);
 
 minutos = D * 2;
 
 printf("%d minutos\n", minutos);
 
  return 0;
}