//https://judge.beecrowd.com/en/problems/view/1018
#include <stdio.h>
 
int main() {
 
    int N;
    scanf("%d", &N);
    printf("%d\n", N);
    int notes[]={100, 50, 20, 10, 5, 2, 1};
    int count[7];
    for(int i=0; i<7; i++){
        count[i] = N/notes[i];
        
        N = N % notes[i];
    }
    
    for(int i=0; i<7; i++){
        printf("%d nota(s) de R$ %d,00\n",count[i], notes[i]);
        
    
    }
 
    return 0;
}