//https://judge.beecrowd.com/en/problems/view/1040
#include <stdio.h>

int main() {
    double N1, N2, N3, N4;
    double exam, Media, finalaverage;

    scanf("%lf %lf %lf %lf", &N1, &N2, &N3, &N4);

    Media = (N1*2 + N2*3 + N3*4 + N4*1) / 10.0;
    printf("Media: %.1lf\n", Media);

    if (Media >= 7.0) {
        printf("Aluno aprovado.\n");
    } 
    else if (Media < 5.0) {
        printf("Aluno reprovado.\n");
    } 
    else {
        printf("Aluno em exame.\n");
        scanf("%lf", &exam);
        printf("Nota do exame: %.1lf\n", exam);

        finalaverage = (Media + exam) / 2.0;

        if (finalaverage >= 5.0) {
            printf("Aluno aprovado.\n");
        } else {
            printf("Aluno reprovado.\n");
        }

        printf("Media final: %.1lf\n", finalaverage);
    }

    return 0;
}
